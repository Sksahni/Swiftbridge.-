# SwiftBridge - Ultra-Fast File Sharing Platform

![SwiftBridge Logo](https://via.placeholder.com/800x200/4F46E5/FFFFFF?text=SwiftBridge)

SwiftBridge is a modern, secure, and blazingly fast file sharing platform that enables seamless cross-device transfers using WebRTC P2P technology with cloud fallback, end-to-end encryption, and comprehensive user management.

## 🚀 Features

### Core Features
- **🔥 Ultra-Fast P2P Transfers**: WebRTC DataChannel for direct browser-to-browser transfers
- **🔒 End-to-End Encryption**: Client-side encryption with ephemeral keys per transfer
- **📱 Cross-Platform**: Web PWA supporting desktop and mobile devices
- **🔄 Resumable Uploads**: Chunked transfers with automatic resume capability
- **🌐 LAN & Remote**: Discover devices on local network or share via internet
- **🔗 Shareable Links**: Generate expiring, password-protected share links
- **👥 User Accounts**: Full authentication with transfer history and device management
- **☁️ Cloud Fallback**: Automatic fallback to S3/R2 when P2P unavailable
- **📊 Admin Dashboard**: Usage metrics, billing, and system monitoring

### Security Features
- End-to-end encryption (E2EE) with X25519 ECDH key exchange
- AES-GCM or ChaCha20-Poly1305 chunk encryption
- Per-chunk integrity verification (SHA-256)
- Password-protected links
- Automatic link expiration
- Audit logging for compliance

### Performance Features
- WebRTC DataChannel for P2P transfers
- WebTransport/QUIC support (experimental)
- Parallel chunk streaming
- Congestion control
- Bandwidth optimization

## 📋 Table of Contents

- [Architecture](#architecture)
- [Tech Stack](#tech-stack)
- [Prerequisites](#prerequisites)
- [Quick Start](#quick-start)
- [Development Setup](#development-setup)
- [Deployment](#deployment)
- [API Documentation](#api-documentation)
- [Configuration](#configuration)
- [Testing](#testing)
- [Monitoring](#monitoring)
- [Contributing](#contributing)
- [License](#license)

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                         Client Layer                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │   Desktop    │  │    Mobile    │  │    Tablet    │      │
│  │   Browser    │  │   Browser    │  │   Browser    │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│         │                  │                  │              │
│         └──────────────────┴──────────────────┘              │
│                            │                                 │
│                    WebRTC P2P / HTTPS                        │
│                            │                                 │
├─────────────────────────────────────────────────────────────┤
│                      Application Layer                       │
│  ┌──────────────────────────────────────────────────────┐   │
│  │              Next.js Web Application                  │   │
│  │  (React, TypeScript, Tailwind CSS, PWA)             │   │
│  └──────────────────────────────────────────────────────┘   │
│  ┌──────────────────────────────────────────────────────┐   │
│  │         Signaling Server (Fastify + WebSocket)       │   │
│  │  (WebRTC negotiation, device discovery)             │   │
│  └──────────────────────────────────────────────────────┘   │
├─────────────────────────────────────────────────────────────┤
│                       Service Layer                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │   TURN/STUN  │  │   Storage    │  │   Database   │      │
│  │   (coturn)   │  │   (S3/R2)    │  │  (Postgres)  │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │    Redis     │  │   Monitoring │  │    Email     │      │
│  │   (Cache)    │  │   (Sentry)   │  │  (SendGrid)  │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
└─────────────────────────────────────────────────────────────┘
```

## 🛠️ Tech Stack

### Frontend
- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **State Management**: React Context + Hooks
- **PWA**: next-pwa
- **WebRTC**: Native WebRTC APIs
- **Encryption**: WebCrypto API + libsodium

### Backend
- **API**: Next.js API Routes / Fastify
- **Language**: TypeScript / Node.js
- **Signaling**: WebSocket (Socket.io / native ws)
- **Database**: PostgreSQL 15
- **ORM**: Prisma
- **Cache**: Redis 7
- **Storage**: AWS S3 / Cloudflare R2
- **TURN/STUN**: coturn

### Infrastructure
- **Hosting**: Vercel (Frontend) / AWS ECS (Backend)
- **CDN**: Cloudflare
- **CI/CD**: GitHub Actions
- **IaC**: Terraform
- **Monitoring**: Sentry, Prometheus, Grafana
- **Logging**: CloudWatch / Datadog

### DevOps
- **Containerization**: Docker
- **Orchestration**: Docker Compose (dev) / ECS (prod)
- **Load Balancing**: AWS ALB
- **SSL/TLS**: AWS ACM / Let's Encrypt

## 📦 Prerequisites

- **Node.js**: 20.x or higher
- **npm**: 9.x or higher
- **Docker**: 24.x or higher
- **Docker Compose**: 2.x or higher
- **PostgreSQL**: 15.x or higher (or use Docker)
- **Redis**: 7.x or higher (or use Docker)

## 🚀 Quick Start

### 1. Clone the Repository

```bash
git clone https://github.com/yourusername/swiftbridge.git
cd swiftbridge
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Setup Environment Variables

```bash
cp .env.example .env
# Edit .env with your configuration
```

### 4. Start Development Environment

```bash
# Start all services with Docker Compose
docker-compose up -d

# Wait for services to be ready
docker-compose ps

# Run database migrations
npm run db:migrate

# Seed database (optional)
npm run db:seed
```

### 5. Start Development Server

```bash
# Start Next.js development server
npm run dev

# In another terminal, start signaling server
npm run dev:signaling
```

### 6. Access the Application

- **Web App**: http://localhost:3000
- **API Docs**: http://localhost:3000/api/docs
- **Signaling Server**: ws://localhost:8080
- **MinIO Console**: http://localhost:9001 (minioadmin / minioadmin123)
- **Adminer (DB)**: http://localhost:8081
- **Grafana**: http://localhost:3001 (admin / admin)

## 💻 Development Setup

### Project Structure

```
swiftbridge/
├── apps/
│   ├── web/                    # Next.js web application
│   │   ├── app/               # Next.js app directory
│   │   ├── components/        # React components
│   │   ├── hooks/             # Custom React hooks
│   │   ├── lib/               # Utility libraries
│   │   └── public/            # Static assets
│   └── admin/                 # Admin dashboard (optional)
├── services/
│   ├── signaling/             # WebSocket signaling server
│   └── uploader/              # File upload service
├── libs/
│   ├── crypto/                # Encryption utilities
│   ├── chunker/               # File chunking logic
│   └── shared/                # Shared utilities
├── infra/
│   └── terraform/             # Infrastructure as code
├── coturn/                    # TURN server configuration
├── monitoring/                # Monitoring configs
├── scripts/                   # Utility scripts
├── tests/                     # Test suites
├── .github/                   # GitHub Actions workflows
├── docker-compose.yml         # Local development setup
├── schema.sql                 # Database schema
├── schema.prisma              # Prisma schema
├── openapi.yaml              # API specification
└── README.md                  # This file
```

### Database Setup

```bash
# Create database
createdb swiftbridge

# Run migrations
npm run db:migrate

# Generate Prisma client
npm run db:generate

# Seed database
npm run db:seed

# Reset database (caution!)
npm run db:reset
```

### Running Tests

```bash
# Run all tests
npm test

# Run unit tests
npm run test:unit

# Run integration tests
npm run test:integration

# Run E2E tests
npm run test:e2e

# Run tests with coverage
npm run test:coverage
```

### Code Quality

```bash
# Lint code
npm run lint

# Fix linting issues
npm run lint:fix

# Format code
npm run format

# Type check
npm run type-check
```

## 🚢 Deployment

### Production Deployment with Terraform

1. **Configure AWS Credentials**

```bash
export AWS_ACCESS_KEY_ID=your_access_key
export AWS_SECRET_ACCESS_KEY=your_secret_key
export AWS_REGION=us-east-1
```

2. **Initialize Terraform**

```bash
cd infra/terraform
terraform init
```

3. **Plan Deployment**

```bash
terraform plan -var="environment=production" -var="db_password=your_secure_password"
```

4. **Apply Infrastructure**

```bash
terraform apply -var="environment=production" -var="db_password=your_secure_password"
```

5. **Deploy Application**

```bash
# Build and push Docker images
npm run build:docker

# Deploy to ECS
npm run deploy:production
```

### Vercel Deployment (Frontend)

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy to Vercel
vercel --prod
```

### Environment-Specific Deployments

```bash
# Deploy to staging
npm run deploy:staging

# Deploy to production
npm run deploy:production

# Rollback deployment
npm run deploy:rollback
```

## 📚 API Documentation

### OpenAPI Specification

The complete API specification is available in `openapi.yaml`. You can view it using:

- **Swagger UI**: http://localhost:3000/api/docs
- **Redoc**: http://localhost:3000/api/redoc
- **OpenAPI JSON**: http://localhost:3000/api/openapi.json

### Key Endpoints

#### Authentication
- `POST /api/auth/signup` - Register new user
- `POST /api/auth/login` - Login user
- `GET /api/auth/me` - Get current user
- `POST /api/auth/signout` - Sign out user

#### Transfers
- `POST /api/transfers` - Create new transfer
- `GET /api/transfers` - List user transfers
- `GET /api/transfers/:id` - Get transfer details
- `GET /api/transfers/:id/status` - Get transfer status
- `POST /api/transfers/:id/complete` - Mark transfer complete
- `POST /api/transfers/:id/revoke` - Revoke transfer

#### Storage
- `POST /api/presign` - Get presigned upload URL

#### Devices
- `GET /api/devices` - List user devices
- `POST /api/devices` - Register new device
- `DELETE /api/devices/:id` - Remove device

### WebSocket Signaling

Connect to `ws://localhost:8080` for WebRTC signaling.

**Message Types:**
- `announce` - Announce device presence
- `offer` - Send WebRTC offer
- `answer` - Send WebRTC answer
- `ice` - Exchange ICE candidates
- `bye` - Close connection

## ⚙️ Configuration

### Environment Variables

See `.env.example` for all available configuration options.

**Critical Variables:**
- `DATABASE_URL` - PostgreSQL connection string
- `REDIS_URL` - Redis connection string
- `JWT_SECRET` - JWT signing secret
- `S3_*` - Storage configuration
- `TURN_*` - TURN server configuration

### Feature Flags

Enable/disable features via environment variables:

```bash
ENABLE_GUEST_TRANSFERS=true
ENABLE_PASSWORD_PROTECTION=true
ENABLE_LINK_EXPIRATION=true
ENABLE_EMAIL_NOTIFICATIONS=true
ENABLE_WEBTRANSPORT=false
```

### Subscription Limits

Configure limits per plan in the database:

```sql
UPDATE subscription_limits 
SET max_file_size_bytes = 10737418240 
WHERE plan = 'pro';
```

## 🧪 Testing

### Test Structure

```
tests/
├── unit/              # Unit tests
├── integration/       # Integration tests
├── e2e/              # End-to-end tests
└── fixtures/         # Test fixtures
```

### Running Specific Tests

```bash
# Run specific test file
npm test -- path/to/test.spec.ts

# Run tests in watch mode
npm test -- --watch

# Run tests with specific pattern
npm test -- --testNamePattern="transfer"
```

## 📊 Monitoring

### Metrics

- **Application Metrics**: Prometheus + Grafana
- **Error Tracking**: Sentry
- **Logs**: CloudWatch / Datadog
- **Uptime**: UptimeRobot / Pingdom

### Dashboards

Access monitoring dashboards:
- **Grafana**: http://localhost:3001
- **Prometheus**: http://localhost:9090

### Alerts

Configure alerts in `monitoring/alerts.yml`:
- High error rate
- Slow response times
- Database connection issues
- High memory usage
- TURN server failures

## 🔐 Security

### Best Practices

1. **Always use HTTPS** in production
2. **Rotate secrets** regularly
3. **Enable rate limiting** on all endpoints
4. **Use strong passwords** for database and services
5. **Keep dependencies updated**
6. **Enable audit logging**
7. **Use environment-specific credentials**

### Security Checklist

- [ ] HTTPS enabled
- [ ] JWT secrets rotated
- [ ] Database encrypted at rest
- [ ] S3 buckets private
- [ ] CORS configured correctly
- [ ] Rate limiting enabled
- [ ] Input validation on all endpoints
- [ ] SQL injection prevention
- [ ] XSS protection
- [ ] CSRF protection

## 🤝 Contributing

We welcome contributions! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for details.

### Development Workflow

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Code Style

- Follow TypeScript best practices
- Use ESLint and Prettier
- Write tests for new features
- Update documentation

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- [WebRTC](https://webrtc.org/) - Real-time communication
- [Next.js](https://nextjs.org/) - React framework
- [Prisma](https://www.prisma.io/) - Database ORM
- [coturn](https://github.com/coturn/coturn) - TURN server
- [Tailwind CSS](https://tailwindcss.com/) - CSS framework

## 📞 Support

- **Documentation**: https://docs.swiftbridge.example
- **Issues**: https://github.com/yourusername/swiftbridge/issues
- **Discord**: https://discord.gg/swiftbridge
- **Email**: support@swiftbridge.example

## 🗺️ Roadmap

### Phase 1 (MVP) - Q1 2025
- [x] Core P2P transfer functionality
- [x] User authentication
- [x] Basic UI/UX
- [x] Cloud fallback
- [ ] Mobile PWA optimization

### Phase 2 (Beta) - Q2 2025
- [ ] Team collaboration features
- [ ] Advanced analytics
- [ ] Native desktop app (Electron)
- [ ] Enhanced security features
- [ ] API for third-party integrations

### Phase 3 (v1.0) - Q3 2025
- [ ] Enterprise features (SSO, SAML)
- [ ] Advanced admin controls
- [ ] White-label options
- [ ] Multi-region deployment
- [ ] Compliance certifications (SOC2, GDPR)

### Future
- [ ] Native mobile apps (iOS, Android)
- [ ] Blockchain-based verification
- [ ] AI-powered file organization
- [ ] Integration marketplace
- [ ] Self-hosted option

---

**Built with ❤️ by the SwiftBridge Team**

For more information, visit [swiftbridge.example](https://swiftbridge.example)