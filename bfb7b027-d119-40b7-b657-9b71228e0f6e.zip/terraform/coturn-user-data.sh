#!/bin/bash
set -e

# Update system
apt-get update
apt-get upgrade -y

# Install coturn
apt-get install -y coturn

# Enable coturn service
sed -i 's/#TURNSERVER_ENABLED=1/TURNSERVER_ENABLED=1/' /etc/default/coturn

# Configure coturn
cat > /etc/turnserver.conf <<EOF
# Listening port for TURN server
listening-port=3478
tls-listening-port=5349

# Listening IP addresses
listening-ip=0.0.0.0

# External IP address
external-ip=$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)

# Relay IP address
relay-ip=$(curl -s http://169.254.169.254/latest/meta-data/local-ipv4)

# Relay ports range
min-port=49152
max-port=65535

# Use fingerprints in TURN messages
fingerprint

# Use long-term credentials mechanism
lt-cred-mech

# Static user credentials (for development/testing)
# In production, use dynamic credentials via REST API
user=swiftbridge:${turn_secret}

# Realm for TURN server
realm=swiftbridge.example

# Log file
log-file=/var/log/turnserver.log
verbose

# Disable UDP relay endpoints
# no-udp-relay

# Disable TCP relay endpoints
# no-tcp-relay

# Enable STUN
# stun-only

# Deny access to private IP ranges
no-multicast-peers
denied-peer-ip=0.0.0.0-0.255.255.255
denied-peer-ip=10.0.0.0-10.255.255.255
denied-peer-ip=100.64.0.0-100.127.255.255
denied-peer-ip=127.0.0.0-127.255.255.255
denied-peer-ip=169.254.0.0-169.254.255.255
denied-peer-ip=172.16.0.0-172.31.255.255
denied-peer-ip=192.0.0.0-192.0.0.255
denied-peer-ip=192.0.2.0-192.0.2.255
denied-peer-ip=192.88.99.0-192.88.99.255
denied-peer-ip=192.168.0.0-192.168.255.255
denied-peer-ip=198.18.0.0-198.19.255.255
denied-peer-ip=198.51.100.0-198.51.100.255
denied-peer-ip=203.0.113.0-203.0.113.255
denied-peer-ip=240.0.0.0-255.255.255.255

# TLS/DTLS configuration (optional, requires certificates)
# cert=/etc/ssl/certs/turn_server_cert.pem
# pkey=/etc/ssl/private/turn_server_pkey.pem

# Mobility with ICE
mobility

# Prometheus metrics
prometheus

# CLI access
cli-password=${turn_secret}
EOF

# Set proper permissions
chmod 600 /etc/turnserver.conf

# Generate self-signed certificate for TLS (production should use Let's Encrypt)
openssl req -x509 -newkey rsa:4096 -keyout /etc/ssl/private/turn_server_pkey.pem \
  -out /etc/ssl/certs/turn_server_cert.pem -days 365 -nodes \
  -subj "/C=US/ST=State/L=City/O=SwiftBridge/CN=turn.swiftbridge.example"

chmod 600 /etc/ssl/private/turn_server_pkey.pem

# Update turnserver.conf with certificate paths
cat >> /etc/turnserver.conf <<EOF

# TLS certificates
cert=/etc/ssl/certs/turn_server_cert.pem
pkey=/etc/ssl/private/turn_server_pkey.pem
EOF

# Start and enable coturn service
systemctl restart coturn
systemctl enable coturn

# Install monitoring tools
apt-get install -y prometheus-node-exporter

# Configure log rotation
cat > /etc/logrotate.d/turnserver <<EOF
/var/log/turnserver.log {
    daily
    rotate 7
    compress
    delaycompress
    missingok
    notifempty
    create 0640 turnserver turnserver
    postrotate
        systemctl reload coturn > /dev/null 2>&1 || true
    endscript
}
EOF

# Setup CloudWatch logs agent (optional)
wget https://s3.amazonaws.com/amazoncloudwatch-agent/ubuntu/amd64/latest/amazon-cloudwatch-agent.deb
dpkg -i -E ./amazon-cloudwatch-agent.deb

# Create CloudWatch config
cat > /opt/aws/amazon-cloudwatch-agent/etc/config.json <<EOF
{
  "logs": {
    "logs_collected": {
      "files": {
        "collect_list": [
          {
            "file_path": "/var/log/turnserver.log",
            "log_group_name": "/coturn/swiftbridge",
            "log_stream_name": "{instance_id}"
          }
        ]
      }
    }
  }
}
EOF

# Start CloudWatch agent
/opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl \
  -a fetch-config \
  -m ec2 \
  -s \
  -c file:/opt/aws/amazon-cloudwatch-agent/etc/config.json

echo "coturn installation and configuration complete!"