-- SwiftBridge Database Schema
-- PostgreSQL 14+

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT,
    name TEXT,
    billing_customer_id TEXT,
    subscription_plan TEXT DEFAULT 'free' CHECK (subscription_plan IN ('free', 'pro', 'enterprise')),
    is_admin BOOLEAN DEFAULT FALSE,
    email_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create index on email for faster lookups
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_subscription ON users(subscription_plan);

-- Devices table
CREATE TABLE devices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    device_type TEXT, -- 'desktop', 'mobile', 'tablet', 'web'
    last_seen TIMESTAMPTZ DEFAULT NOW(),
    public_key TEXT, -- For persistent device pairing
    capabilities JSONB DEFAULT '{}', -- WebRTC, WebTransport support flags
    ip_address INET,
    user_agent TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_devices_user_id ON devices(user_id);
CREATE INDEX idx_devices_last_seen ON devices(last_seen);
CREATE INDEX idx_devices_active ON devices(is_active) WHERE is_active = TRUE;

-- Transfers table
CREATE TABLE transfers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    title TEXT,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'completed', 'failed', 'revoked', 'expired')),
    total_bytes BIGINT DEFAULT 0,
    bytes_sent BIGINT DEFAULT 0,
    mode TEXT DEFAULT 'webrtc' CHECK (mode IN ('webrtc', 'webtransport', 'server', 'mixed')),
    share_token TEXT UNIQUE, -- For shareable links
    password_hash TEXT, -- Optional password protection
    expire_at TIMESTAMPTZ,
    max_downloads INTEGER DEFAULT 0,
    download_count INTEGER DEFAULT 0,
    require_auth BOOLEAN DEFAULT FALSE,
    metadata JSONB DEFAULT '{}', -- Additional transfer metadata
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

CREATE INDEX idx_transfers_user_id ON transfers(user_id);
CREATE INDEX idx_transfers_status ON transfers(status);
CREATE INDEX idx_transfers_share_token ON transfers(share_token);
CREATE INDEX idx_transfers_created_at ON transfers(created_at DESC);
CREATE INDEX idx_transfers_expire_at ON transfers(expire_at) WHERE expire_at IS NOT NULL;

-- Files table
CREATE TABLE files (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    transfer_id UUID NOT NULL REFERENCES transfers(id) ON DELETE CASCADE,
    filename TEXT NOT NULL,
    original_filename TEXT NOT NULL,
    size BIGINT NOT NULL,
    mime_type TEXT,
    chunk_count INTEGER NOT NULL DEFAULT 1,
    hash TEXT NOT NULL, -- SHA-256 hash
    encrypted_metadata JSONB DEFAULT '{}', -- Per-chunk IVs, nonces, etc.
    storage_key TEXT, -- S3/R2 object key if server-side
    storage_provider TEXT, -- 's3', 'r2', 'local'
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'uploading', 'uploaded', 'verified', 'failed')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_files_transfer_id ON files(transfer_id);
CREATE INDEX idx_files_status ON files(status);
CREATE INDEX idx_files_hash ON files(hash);

-- Chunks table (for resumable uploads)
CREATE TABLE chunks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    file_id UUID NOT NULL REFERENCES files(id) ON DELETE CASCADE,
    chunk_index INTEGER NOT NULL,
    size BIGINT NOT NULL,
    checksum TEXT NOT NULL, -- SHA-256 of chunk
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'uploaded', 'verified', 'failed')),
    storage_key TEXT, -- S3/R2 object key for this chunk
    retry_count INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(file_id, chunk_index)
);

CREATE INDEX idx_chunks_file_id ON chunks(file_id);
CREATE INDEX idx_chunks_status ON chunks(status);

-- Transfer recipients table
CREATE TABLE transfer_recipients (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    transfer_id UUID NOT NULL REFERENCES transfers(id) ON DELETE CASCADE,
    recipient_type TEXT NOT NULL CHECK (recipient_type IN ('device', 'email', 'link')),
    recipient_value TEXT, -- Device ID, email, or NULL for link
    device_id UUID REFERENCES devices(id) ON DELETE SET NULL,
    notified BOOLEAN DEFAULT FALSE,
    downloaded BOOLEAN DEFAULT FALSE,
    downloaded_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_transfer_recipients_transfer_id ON transfer_recipients(transfer_id);
CREATE INDEX idx_transfer_recipients_device_id ON transfer_recipients(device_id);

-- Audit logs table
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    transfer_id UUID REFERENCES transfers(id) ON DELETE SET NULL,
    action TEXT NOT NULL, -- 'transfer_created', 'transfer_completed', 'link_accessed', etc.
    ip_address INET,
    user_agent TEXT,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_transfer_id ON audit_logs(transfer_id);
CREATE INDEX idx_audit_logs_action ON audit_logs(action);
CREATE INDEX idx_audit_logs_created_at ON audit_logs(created_at DESC);

-- Sessions table (for JWT refresh tokens)
CREATE TABLE sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    refresh_token TEXT UNIQUE NOT NULL,
    device_id UUID REFERENCES devices(id) ON DELETE CASCADE,
    ip_address INET,
    user_agent TEXT,
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    last_used_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_sessions_user_id ON sessions(user_id);
CREATE INDEX idx_sessions_refresh_token ON sessions(refresh_token);
CREATE INDEX idx_sessions_expires_at ON sessions(expires_at);

-- Subscription limits table
CREATE TABLE subscription_limits (
    plan TEXT PRIMARY KEY CHECK (plan IN ('free', 'pro', 'enterprise')),
    max_file_size_bytes BIGINT NOT NULL,
    max_transfers_per_day INTEGER NOT NULL,
    max_storage_gb INTEGER NOT NULL,
    max_transfer_speed_mbps INTEGER,
    link_expiry_days INTEGER,
    features JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Insert default subscription limits
INSERT INTO subscription_limits (plan, max_file_size_bytes, max_transfers_per_day, max_storage_gb, max_transfer_speed_mbps, link_expiry_days, features) VALUES
('free', 104857600, 10, 1, 10, 7, '{"password_protection": false, "custom_branding": false, "analytics": false}'),
('pro', 10737418240, 100, 100, 100, 30, '{"password_protection": true, "custom_branding": false, "analytics": true}'),
('enterprise', 107374182400, 1000, 1000, 1000, 365, '{"password_protection": true, "custom_branding": true, "analytics": true, "api_access": true}');

-- Usage tracking table
CREATE TABLE usage_tracking (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    date DATE NOT NULL DEFAULT CURRENT_DATE,
    transfers_count INTEGER DEFAULT 0,
    bytes_transferred BIGINT DEFAULT 0,
    storage_used_bytes BIGINT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, date)
);

CREATE INDEX idx_usage_tracking_user_date ON usage_tracking(user_id, date DESC);

-- Notifications table
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type TEXT NOT NULL, -- 'transfer_received', 'transfer_completed', 'link_accessed', etc.
    title TEXT NOT NULL,
    message TEXT,
    read BOOLEAN DEFAULT FALSE,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_notifications_read ON notifications(read) WHERE read = FALSE;
CREATE INDEX idx_notifications_created_at ON notifications(created_at DESC);

-- WebRTC signaling sessions (ephemeral, can be in Redis in production)
CREATE TABLE signaling_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    device_id UUID NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
    session_token TEXT UNIQUE NOT NULL,
    peer_id TEXT,
    sdp_offer TEXT,
    sdp_answer TEXT,
    ice_candidates JSONB DEFAULT '[]',
    ephemeral_public_key TEXT, -- For E2EE key exchange
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'negotiating', 'connected', 'failed', 'closed')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    expires_at TIMESTAMPTZ DEFAULT NOW() + INTERVAL '1 hour'
);

CREATE INDEX idx_signaling_sessions_device_id ON signaling_sessions(device_id);
CREATE INDEX idx_signaling_sessions_session_token ON signaling_sessions(session_token);
CREATE INDEX idx_signaling_sessions_expires_at ON signaling_sessions(expires_at);

-- Functions and Triggers

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply updated_at trigger to relevant tables
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_transfers_updated_at BEFORE UPDATE ON transfers
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_files_updated_at BEFORE UPDATE ON files
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_chunks_updated_at BEFORE UPDATE ON chunks
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function to clean up expired transfers
CREATE OR REPLACE FUNCTION cleanup_expired_transfers()
RETURNS void AS $$
BEGIN
    UPDATE transfers
    SET status = 'expired'
    WHERE expire_at < NOW()
    AND status NOT IN ('completed', 'revoked', 'expired');
END;
$$ LANGUAGE plpgsql;

-- Function to clean up expired sessions
CREATE OR REPLACE FUNCTION cleanup_expired_sessions()
RETURNS void AS $$
BEGIN
    DELETE FROM sessions
    WHERE expires_at < NOW();
    
    DELETE FROM signaling_sessions
    WHERE expires_at < NOW();
END;
$$ LANGUAGE plpgsql;

-- Function to update usage tracking
CREATE OR REPLACE FUNCTION update_usage_tracking(
    p_user_id UUID,
    p_bytes_transferred BIGINT
)
RETURNS void AS $$
BEGIN
    INSERT INTO usage_tracking (user_id, date, transfers_count, bytes_transferred)
    VALUES (p_user_id, CURRENT_DATE, 1, p_bytes_transferred)
    ON CONFLICT (user_id, date)
    DO UPDATE SET
        transfers_count = usage_tracking.transfers_count + 1,
        bytes_transferred = usage_tracking.bytes_transferred + p_bytes_transferred,
        updated_at = NOW();
END;
$$ LANGUAGE plpgsql;

-- Views

-- Active transfers view
CREATE VIEW active_transfers_view AS
SELECT 
    t.id,
    t.user_id,
    u.email as user_email,
    t.title,
    t.status,
    t.total_bytes,
    t.bytes_sent,
    ROUND((t.bytes_sent::NUMERIC / NULLIF(t.total_bytes, 0)) * 100, 2) as progress_percentage,
    t.mode,
    t.created_at,
    COUNT(f.id) as file_count
FROM transfers t
LEFT JOIN users u ON t.user_id = u.id
LEFT JOIN files f ON t.transfer_id = f.id
WHERE t.status IN ('pending', 'active')
GROUP BY t.id, u.email;

-- User statistics view
CREATE VIEW user_stats_view AS
SELECT 
    u.id as user_id,
    u.email,
    u.subscription_plan,
    COUNT(DISTINCT t.id) as total_transfers,
    COUNT(DISTINCT t.id) FILTER (WHERE t.status = 'completed') as completed_transfers,
    COALESCE(SUM(t.total_bytes), 0) as total_bytes_transferred,
    COUNT(DISTINCT d.id) as device_count,
    MAX(t.created_at) as last_transfer_at
FROM users u
LEFT JOIN transfers t ON u.id = t.user_id
LEFT JOIN devices d ON u.id = d.user_id
GROUP BY u.id, u.email, u.subscription_plan;

-- Comments for documentation
COMMENT ON TABLE users IS 'User accounts and authentication';
COMMENT ON TABLE devices IS 'Registered devices for each user';
COMMENT ON TABLE transfers IS 'File transfer sessions';
COMMENT ON TABLE files IS 'Individual files within transfers';
COMMENT ON TABLE chunks IS 'File chunks for resumable uploads';
COMMENT ON TABLE transfer_recipients IS 'Recipients for each transfer';
COMMENT ON TABLE audit_logs IS 'Audit trail for security and compliance';
COMMENT ON TABLE sessions IS 'User sessions and refresh tokens';
COMMENT ON TABLE subscription_limits IS 'Plan limits and features';
COMMENT ON TABLE usage_tracking IS 'Daily usage metrics per user';
COMMENT ON TABLE notifications IS 'User notifications';
COMMENT ON TABLE signaling_sessions IS 'WebRTC signaling state (ephemeral)';

-- Grant permissions (adjust as needed for your setup)
-- GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO swiftbridge_app;
-- GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO swiftbridge_app;