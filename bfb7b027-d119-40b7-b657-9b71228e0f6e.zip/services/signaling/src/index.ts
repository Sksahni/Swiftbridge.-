import Fastify from 'fastify';
import cors from '@fastify/cors';
import websocket from '@fastify/websocket';
import Redis from 'ioredis';
import jwt from 'jsonwebtoken';
import { PrismaClient } from '@prisma/client';

const fastify = Fastify({
  logger: {
    level: process.env.LOG_LEVEL || 'info',
    transport: {
      target: 'pino-pretty',
      options: {
        colorize: true,
        translateTime: 'HH:MM:ss Z',
        ignore: 'pid,hostname',
      },
    },
  },
});

const prisma = new PrismaClient();
const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');

// Store active connections
const connections = new Map<string, any>();

// Register plugins
fastify.register(cors, {
  origin: process.env.CORS_ORIGIN || '*',
  credentials: true,
});

fastify.register(websocket);

// Health check endpoint
fastify.get('/health', async (request, reply) => {
  return { status: 'ok', timestamp: new Date().toISOString() };
});

// WebSocket signaling endpoint
fastify.register(async function (fastify) {
  fastify.get('/ws', { websocket: true }, (connection, req) => {
    const { socket } = connection;
    let deviceId: string | null = null;
    let userId: string | null = null;

    fastify.log.info('New WebSocket connection');

    socket.on('message', async (message: Buffer) => {
      try {
        const data = JSON.parse(message.toString());
        fastify.log.debug({ data }, 'Received message');

        switch (data.type) {
          case 'auth':
            // Authenticate connection
            try {
              const token = data.token;
              const decoded = jwt.verify(
                token,
                process.env.JWT_SECRET || 'dev_secret'
              ) as any;
              
              userId = decoded.userId;
              deviceId = data.deviceId;

              // Store connection
              connections.set(deviceId, { socket, userId, deviceId });

              // Update device last seen
              await prisma.device.update({
                where: { id: deviceId },
                data: { lastSeen: new Date() },
              });

              // Store presence in Redis
              await redis.setex(
                `presence:${deviceId}`,
                300, // 5 minutes TTL
                JSON.stringify({ userId, deviceId, timestamp: Date.now() })
              );

              socket.send(
                JSON.stringify({
                  type: 'auth_success',
                  deviceId,
                })
              );

              fastify.log.info({ userId, deviceId }, 'Client authenticated');
            } catch (error) {
              socket.send(
                JSON.stringify({
                  type: 'auth_error',
                  message: 'Invalid token',
                })
              );
              socket.close();
            }
            break;

          case 'announce':
            // Announce device presence
            if (!deviceId) {
              socket.send(
                JSON.stringify({
                  type: 'error',
                  message: 'Not authenticated',
                })
              );
              return;
            }

            // Broadcast to other devices of the same user
            const userDevices = Array.from(connections.values()).filter(
              (conn) => conn.userId === userId && conn.deviceId !== deviceId
            );

            userDevices.forEach((conn) => {
              conn.socket.send(
                JSON.stringify({
                  type: 'device_announced',
                  device: data.device,
                })
              );
            });

            fastify.log.info({ deviceId, device: data.device }, 'Device announced');
            break;

          case 'offer':
            // Forward WebRTC offer to target device
            const targetOffer = connections.get(data.to);
            if (targetOffer) {
              targetOffer.socket.send(
                JSON.stringify({
                  type: 'offer',
                  from: deviceId,
                  sdp: data.sdp,
                  publicKey: data.publicKey,
                })
              );
              fastify.log.info({ from: deviceId, to: data.to }, 'Forwarded offer');
            } else {
              socket.send(
                JSON.stringify({
                  type: 'error',
                  message: 'Target device not found',
                })
              );
            }
            break;

          case 'answer':
            // Forward WebRTC answer to target device
            const targetAnswer = connections.get(data.to);
            if (targetAnswer) {
              targetAnswer.socket.send(
                JSON.stringify({
                  type: 'answer',
                  from: deviceId,
                  sdp: data.sdp,
                  publicKey: data.publicKey,
                })
              );
              fastify.log.info({ from: deviceId, to: data.to }, 'Forwarded answer');
            }
            break;

          case 'ice':
            // Forward ICE candidate to target device
            const targetIce = connections.get(data.to);
            if (targetIce) {
              targetIce.socket.send(
                JSON.stringify({
                  type: 'ice',
                  from: deviceId,
                  candidate: data.candidate,
                })
              );
              fastify.log.debug({ from: deviceId, to: data.to }, 'Forwarded ICE candidate');
            }
            break;

          case 'bye':
            // Close connection to target device
            const targetBye = connections.get(data.to);
            if (targetBye) {
              targetBye.socket.send(
                JSON.stringify({
                  type: 'bye',
                  from: deviceId,
                })
              );
              fastify.log.info({ from: deviceId, to: data.to }, 'Sent bye');
            }
            break;

          default:
            fastify.log.warn({ type: data.type }, 'Unknown message type');
        }
      } catch (error) {
        fastify.log.error({ error }, 'Error processing message');
        socket.send(
          JSON.stringify({
            type: 'error',
            message: 'Internal server error',
          })
        );
      }
    });

    socket.on('close', async () => {
      if (deviceId) {
        connections.delete(deviceId);
        await redis.del(`presence:${deviceId}`);
        fastify.log.info({ deviceId }, 'Connection closed');
      }
    });

    socket.on('error', (error) => {
      fastify.log.error({ error }, 'WebSocket error');
    });
  });
});

// Graceful shutdown
const gracefulShutdown = async () => {
  fastify.log.info('Shutting down gracefully...');
  
  // Close all WebSocket connections
  connections.forEach((conn) => {
    conn.socket.close();
  });
  
  await fastify.close();
  await prisma.$disconnect();
  await redis.quit();
  
  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start server
const start = async () => {
  try {
    const port = parseInt(process.env.PORT || '8080', 10);
    const host = process.env.HOST || '0.0.0.0';
    
    await fastify.listen({ port, host });
    
    fastify.log.info(`Signaling server listening on ${host}:${port}`);
  } catch (err) {
    fastify.log.error(err);
    process.exit(1);
  }
};

start();