# SwiftBridge Setup Guide

This guide will help you set up SwiftBridge for local development.

## Quick Start (5 minutes)

### Prerequisites Check

```bash
# Check Node.js version (should be 20.x or higher)
node --version

# Check npm version (should be 9.x or higher)
npm --version

# Check Docker version (should be 24.x or higher)
docker --version

# Check Docker Compose version (should be 2.x or higher)
docker-compose --version
```

### One-Command Setup

```bash
# Clone and setup
git clone https://github.com/yourusername/swiftbridge.git
cd swiftbridge
npm install
cp .env.example .env
docker-compose up -d
npm run db:migrate
npm run dev
```

That's it! Open http://localhost:3000 in your browser.

## Detailed Setup Instructions

### Step 1: Clone Repository

```bash
git clone https://github.com/yourusername/swiftbridge.git
cd swiftbridge
```

### Step 2: Install Dependencies

```bash
# Install all dependencies
npm install

# This will install dependencies for:
# - Root workspace
# - apps/web (Next.js)
# - services/signaling (Fastify)
# - All shared libraries
```

### Step 3: Environment Configuration

```bash
# Copy example environment file
cp .env.example .env

# Edit .env with your preferred editor
nano .env  # or vim, code, etc.
```

**Minimum required variables for local development:**

```env
# Database
DATABASE_URL=postgresql://swiftbridge:swiftbridge_dev_password@localhost:5432/swiftbridge

# Redis
REDIS_URL=redis://localhost:6379

# JWT Secret (change this!)
JWT_SECRET=your_random_secret_here

# Storage (MinIO for local dev)
S3_ENDPOINT=http://localhost:9000
S3_BUCKET=swiftbridge-uploads
S3_ACCESS_KEY_ID=minioadmin
S3_SECRET_ACCESS_KEY=minioadmin123

# TURN Server
NEXT_PUBLIC_TURN_URL=turn:localhost:3478
NEXT_PUBLIC_TURN_USERNAME=swiftbridge
NEXT_PUBLIC_TURN_PASSWORD=swiftbridge_turn_secret_2024
```

### Step 4: Start Infrastructure Services

```bash
# Start all services (PostgreSQL, Redis, MinIO, coturn, etc.)
docker-compose up -d

# Wait for services to be ready (about 30 seconds)
docker-compose ps

# Check logs if needed
docker-compose logs -f
```

**Services started:**
- PostgreSQL (port 5432)
- Redis (port 6379)
- MinIO (port 9000, console 9001)
- coturn (ports 3478, 5349)
- Adminer (port 8081)
- Prometheus (port 9090)
- Grafana (port 3001)

### Step 5: Database Setup

```bash
# Run database migrations
npm run db:migrate

# Generate Prisma client
npm run db:generate

# (Optional) Seed database with sample data
npm run db:seed
```

### Step 6: Start Development Servers

**Option A: Start all services together**

```bash
npm run dev
```

**Option B: Start services separately (recommended for debugging)**

```bash
# Terminal 1: Start Next.js web app
npm run dev:web

# Terminal 2: Start signaling server
npm run dev:signaling
```

### Step 7: Verify Installation

Open your browser and check:

1. **Web App**: http://localhost:3000
2. **API Health**: http://localhost:3000/api/health
3. **Signaling Server**: ws://localhost:8080 (use wscat or browser console)
4. **MinIO Console**: http://localhost:9001 (minioadmin / minioadmin123)
5. **Database Admin**: http://localhost:8081 (PostgreSQL / swiftbridge / swiftbridge_dev_password)
6. **Grafana**: http://localhost:3001 (admin / admin)

## Development Workflow

### Running Tests

```bash
# Run all tests
npm test

# Run specific test suites
npm run test:unit
npm run test:integration
npm run test:e2e

# Run tests in watch mode
npm test -- --watch

# Run tests with coverage
npm run test:coverage
```

### Code Quality

```bash
# Lint code
npm run lint

# Fix linting issues automatically
npm run lint:fix

# Format code with Prettier
npm run format

# Check TypeScript types
npm run type-check
```

### Database Management

```bash
# Create a new migration
npm run db:migrate:dev -- --name add_new_feature

# Reset database (WARNING: deletes all data)
npm run db:reset

# Open Prisma Studio (GUI for database)
npm run db:studio
```

### Docker Commands

```bash
# View running containers
docker-compose ps

# View logs
docker-compose logs -f [service_name]

# Restart a service
docker-compose restart [service_name]

# Stop all services
docker-compose down

# Stop and remove volumes (clean slate)
docker-compose down -v

# Rebuild containers
docker-compose build
docker-compose up -d
```

## Project Structure

```
swiftbridge/
├── apps/
│   └── web/                    # Next.js web application
│       ├── app/               # Next.js app directory (routes)
│       ├── components/        # React components
│       ├── hooks/             # Custom React hooks
│       ├── lib/               # Utility libraries
│       └── public/            # Static assets
│
├── services/
│   └── signaling/             # WebSocket signaling server
│       └── src/
│           └── index.ts       # Main server file
│
├── libs/                      # Shared libraries
│   ├── crypto/               # Encryption utilities
│   ├── chunker/              # File chunking logic
│   └── shared/               # Shared utilities
│
├── infra/
│   └── terraform/            # Infrastructure as code
│
├── coturn/                   # TURN server configuration
├── monitoring/               # Monitoring configs
├── tests/                    # Test suites
├── .github/                  # GitHub Actions workflows
│
├── docker-compose.yml        # Local development setup
├── schema.sql               # Database schema (SQL)
├── schema.prisma            # Database schema (Prisma)
├── openapi.yaml             # API specification
├── .env.example             # Environment variables template
├── package.json             # Root package.json
└── README.md                # Main documentation
```

## Common Issues & Solutions

### Issue: Port Already in Use

```bash
# Find process using port 3000
lsof -i :3000

# Kill the process
kill -9 <PID>

# Or change the port in .env
PORT=3001
```

### Issue: Database Connection Failed

```bash
# Check if PostgreSQL is running
docker-compose ps postgres

# Restart PostgreSQL
docker-compose restart postgres

# Check logs
docker-compose logs postgres

# Verify connection string in .env
DATABASE_URL=postgresql://swiftbridge:swiftbridge_dev_password@localhost:5432/swiftbridge
```

### Issue: MinIO Bucket Not Found

```bash
# Restart MinIO setup container
docker-compose up -d minio-setup

# Or create bucket manually
# Open http://localhost:9001
# Login: minioadmin / minioadmin123
# Create bucket: swiftbridge-uploads
```

### Issue: TURN Server Not Working

```bash
# Check coturn logs
docker-compose logs coturn

# Test TURN server
npm install -g turn-test
turn-test turn:localhost:3478 swiftbridge swiftbridge_turn_secret_2024

# Restart coturn
docker-compose restart coturn
```

### Issue: WebSocket Connection Failed

```bash
# Check signaling server logs
npm run dev:signaling

# Verify WebSocket URL in browser console
# Should be: ws://localhost:8080

# Check if port 8080 is available
lsof -i :8080
```

### Issue: Prisma Client Not Generated

```bash
# Generate Prisma client
npm run db:generate

# If still failing, try:
rm -rf node_modules/.prisma
npm run db:generate
```

## Development Tips

### Hot Reload

Both Next.js and the signaling server support hot reload:
- Next.js: Automatically reloads on file changes
- Signaling: Uses `tsx watch` for automatic restart

### Debugging

**Next.js (Chrome DevTools):**
```bash
# Start with debugging enabled
NODE_OPTIONS='--inspect' npm run dev:web
```

**Signaling Server:**
```bash
# Start with debugging enabled
NODE_OPTIONS='--inspect' npm run dev:signaling
```

Then open `chrome://inspect` in Chrome.

### Environment-Specific Configuration

```bash
# Development
NODE_ENV=development npm run dev

# Production build locally
NODE_ENV=production npm run build
npm run start
```

### Database Inspection

```bash
# Open Prisma Studio
npm run db:studio

# Or use Adminer
# Open http://localhost:8081
# System: PostgreSQL
# Server: postgres
# Username: swiftbridge
# Password: swiftbridge_dev_password
# Database: swiftbridge
```

### Monitoring Local Development

- **Grafana**: http://localhost:3001 (admin / admin)
  - Pre-configured dashboards for metrics
  
- **Prometheus**: http://localhost:9090
  - Raw metrics and queries

## Next Steps

1. **Read the Documentation**
   - [README.md](README.md) - Project overview
   - [DEPLOYMENT.md](DEPLOYMENT.md) - Production deployment
   - [API Documentation](http://localhost:3000/api/docs) - API reference

2. **Explore the Code**
   - Start with `apps/web/app/page.tsx` for the main page
   - Check `services/signaling/src/index.ts` for WebSocket logic
   - Review `schema.prisma` for database structure

3. **Run Tests**
   ```bash
   npm test
   ```

4. **Make Your First Change**
   - Edit a component in `apps/web/components/`
   - See changes instantly with hot reload
   - Commit your changes

5. **Join the Community**
   - Discord: https://discord.gg/swiftbridge
   - GitHub Discussions: https://github.com/yourusername/swiftbridge/discussions

## Getting Help

- **Documentation**: Check README.md and other docs
- **Issues**: https://github.com/yourusername/swiftbridge/issues
- **Discord**: https://discord.gg/swiftbridge
- **Email**: support@swiftbridge.example

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines on:
- Code style
- Commit messages
- Pull request process
- Testing requirements

---

**Happy coding! 🚀**