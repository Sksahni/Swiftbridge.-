# SwiftBridge - Quick Local Setup Guide

## Two Setup Options

### Option A: Full Setup (With Docker) - Recommended
### Option B: Simplified Setup (Without Docker) - For Testing

---

## Option A: Full Setup with Docker (Recommended)

This is the complete setup with all services running.

### Prerequisites
- Node.js 20+ ✅
- npm 9+ ✅
- Docker 24+ ❌ (not available in sandbox)
- Docker Compose 2+ ❌ (not available in sandbox)

### Steps

```bash
# 1. Install dependencies
npm install

# 2. Copy environment file
cp .env.example .env

# 3. Start all services (PostgreSQL, Redis, MinIO, coturn, etc.)
docker-compose up -d

# Wait about 30 seconds for services to start

# 4. Check services are running
docker-compose ps

# 5. Run database migrations
npm run db:migrate

# 6. Generate Prisma client
npm run db:generate

# 7. (Optional) Seed database
npm run db:seed

# 8. Start development servers
npm run dev
```

### Access Points
- **Web App**: http://localhost:3000
- **Signaling Server**: ws://localhost:8080
- **MinIO Console**: http://localhost:9001 (minioadmin / minioadmin123)
- **Adminer (DB)**: http://localhost:8081
- **Grafana**: http://localhost:3001 (admin / admin)
- **Prometheus**: http://localhost:9090

---

## Option B: Simplified Setup (Without Docker)

For environments where Docker is not available, you can run a simplified version.

### Prerequisites
- Node.js 20+ ✅
- npm 9+ ✅

### What You Can Do Without Docker

1. **Review the Code Structure** ✅
2. **Understand the Architecture** ✅
3. **Read the Documentation** ✅
4. **Examine the API Specification** ✅
5. **Study the Database Schema** ✅
6. **Review the Signaling Server Code** ✅
7. **Test TypeScript Compilation** ✅

### What You Cannot Do Without Docker

- ❌ Run the full application
- ❌ Test database operations
- ❌ Test file uploads to MinIO
- ❌ Test WebRTC signaling
- ❌ Test TURN server

### Steps for Simplified Setup

```bash
# 1. Install dependencies
npm install

# 2. Copy environment file
cp .env.example .env

# 3. Generate Prisma client (will fail without database, but shows structure)
npx prisma generate

# 4. Check TypeScript compilation
npm run type-check

# 5. Run linting
npm run lint

# 6. View the code structure
tree -L 3 -I node_modules
```

---

## What We Can Do Right Now (In Sandbox)

Let me show you what we can explore without Docker:

### 1. Project Structure
```bash
ls -la
```

### 2. View Package Configuration
```bash
cat package.json
```

### 3. Check Environment Variables
```bash
cat .env.example
```

### 4. View API Specification
```bash
head -n 50 openapi.yaml
```

### 5. View Database Schema
```bash
head -n 100 schema.sql
```

### 6. View Signaling Server Code
```bash
cat services/signaling/src/index.ts
```

### 7. View Docker Compose Configuration
```bash
cat docker-compose.yml
```

---

## Recommended Next Steps

### In This Sandbox
1. ✅ Review all documentation files
2. ✅ Examine the code structure
3. ✅ Study the API specification
4. ✅ Understand the database schema
5. ✅ Review the infrastructure code

### On Your Local Machine (With Docker)
1. Clone this repository
2. Install Docker Desktop
3. Follow Option A (Full Setup)
4. Start developing!

---

## Troubleshooting

### "Docker not found"
- **In Sandbox**: This is expected. Use Option B.
- **On Local Machine**: Install Docker Desktop from https://www.docker.com/products/docker-desktop

### "Port already in use"
```bash
# Find process using port
lsof -i :3000

# Kill the process
kill -9 <PID>
```

### "Database connection failed"
```bash
# Check if PostgreSQL is running
docker-compose ps postgres

# Restart PostgreSQL
docker-compose restart postgres
```

### "npm install fails"
```bash
# Clear npm cache
npm cache clean --force

# Delete node_modules and reinstall
rm -rf node_modules package-lock.json
npm install
```

---

## What to Explore Now

Since we're in a sandbox without Docker, let's explore the codebase:

### 1. Documentation
- START_HERE.md - Quick overview
- README.md - Complete documentation
- SETUP.md - Detailed setup guide
- DEPLOYMENT.md - Production deployment

### 2. API Specification
- openapi.yaml - All API endpoints

### 3. Database Schema
- schema.sql - PostgreSQL schema
- schema.prisma - Prisma ORM schema

### 4. Infrastructure
- terraform/main.tf - AWS infrastructure
- docker-compose.yml - Local services

### 5. Application Code
- services/signaling/src/index.ts - WebSocket server
- package.json - Project configuration

---

## Summary

**In Sandbox (Now)**:
- ✅ Review documentation
- ✅ Study code structure
- ✅ Understand architecture
- ✅ Examine specifications

**On Local Machine (Later)**:
- ✅ Full Docker setup
- ✅ Run all services
- ✅ Develop features
- ✅ Test functionality

---

Would you like me to:
1. Show you specific files?
2. Explain the architecture?
3. Walk through the API?
4. Review the database schema?
5. Explain deployment options?