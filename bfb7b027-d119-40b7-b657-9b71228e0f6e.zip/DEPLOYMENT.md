# SwiftBridge Deployment Guide

This guide covers deploying SwiftBridge to production environments.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Infrastructure Setup](#infrastructure-setup)
3. [Database Setup](#database-setup)
4. [Application Deployment](#application-deployment)
5. [TURN Server Setup](#turn-server-setup)
6. [Monitoring Setup](#monitoring-setup)
7. [Post-Deployment](#post-deployment)
8. [Troubleshooting](#troubleshooting)

## Prerequisites

### Required Accounts
- AWS Account (or alternative cloud provider)
- Cloudflare Account (for CDN and DNS)
- GitHub Account (for CI/CD)
- Stripe Account (for payments)
- SendGrid/Postmark Account (for emails)

### Required Tools
- Terraform >= 1.5.0
- AWS CLI >= 2.0
- Docker >= 24.0
- kubectl >= 1.28 (if using Kubernetes)
- Node.js >= 20.0

### Domain Setup
- Purchase a domain name
- Configure DNS with Cloudflare
- Setup SSL certificates

## Infrastructure Setup

### 1. Configure AWS Credentials

```bash
# Configure AWS CLI
aws configure

# Or export credentials
export AWS_ACCESS_KEY_ID=your_access_key
export AWS_SECRET_ACCESS_KEY=your_secret_key
export AWS_REGION=us-east-1
```

### 2. Initialize Terraform

```bash
cd infra/terraform

# Initialize Terraform
terraform init

# Create terraform.tfvars
cat > terraform.tfvars <<EOF
environment = "production"
aws_region = "us-east-1"
domain_name = "swiftbridge.example"
db_password = "your_secure_password_here"
cloudflare_api_token = "your_cloudflare_token"
EOF
```

### 3. Plan Infrastructure

```bash
# Review planned changes
terraform plan

# Save plan to file
terraform plan -out=tfplan
```

### 4. Apply Infrastructure

```bash
# Apply infrastructure changes
terraform apply tfplan

# Or apply directly (with confirmation)
terraform apply
```

### 5. Note Output Values

```bash
# Get output values
terraform output

# Save important values
terraform output -json > outputs.json
```

## Database Setup

### 1. Connect to RDS Instance

```bash
# Get RDS endpoint from Terraform output
RDS_ENDPOINT=$(terraform output -raw rds_endpoint)

# Connect using psql
psql -h $RDS_ENDPOINT -U swiftbridge -d swiftbridge
```

### 2. Run Migrations

```bash
# Set DATABASE_URL
export DATABASE_URL="postgresql://swiftbridge:password@$RDS_ENDPOINT:5432/swiftbridge"

# Run Prisma migrations
npx prisma migrate deploy

# Generate Prisma client
npx prisma generate
```

### 3. Seed Database (Optional)

```bash
# Seed initial data
npx prisma db seed
```

### 4. Create Admin User

```bash
# Run SQL to create admin user
psql -h $RDS_ENDPOINT -U swiftbridge -d swiftbridge <<EOF
INSERT INTO users (email, password_hash, name, is_admin, email_verified)
VALUES (
  'admin@swiftbridge.example',
  '\$2a\$10\$your_bcrypt_hash_here',
  'Admin User',
  true,
  true
);
EOF
```

## Application Deployment

### Option 1: Deploy to AWS ECS (Recommended)

#### 1. Build and Push Docker Images

```bash
# Login to ECR
aws ecr get-login-password --region us-east-1 | \
  docker login --username AWS --password-stdin \
  your-account-id.dkr.ecr.us-east-1.amazonaws.com

# Build images
docker build -t swiftbridge-web:latest -f apps/web/Dockerfile .
docker build -t swiftbridge-signaling:latest -f services/signaling/Dockerfile .

# Tag images
docker tag swiftbridge-web:latest \
  your-account-id.dkr.ecr.us-east-1.amazonaws.com/swiftbridge-web:latest
docker tag swiftbridge-signaling:latest \
  your-account-id.dkr.ecr.us-east-1.amazonaws.com/swiftbridge-signaling:latest

# Push images
docker push your-account-id.dkr.ecr.us-east-1.amazonaws.com/swiftbridge-web:latest
docker push your-account-id.dkr.ecr.us-east-1.amazonaws.com/swiftbridge-signaling:latest
```

#### 2. Create ECS Task Definitions

```bash
# Create task definition for web app
aws ecs register-task-definition --cli-input-json file://ecs-task-web.json

# Create task definition for signaling server
aws ecs register-task-definition --cli-input-json file://ecs-task-signaling.json
```

#### 3. Create ECS Services

```bash
# Create web service
aws ecs create-service \
  --cluster swiftbridge-production \
  --service-name swiftbridge-web \
  --task-definition swiftbridge-web:1 \
  --desired-count 2 \
  --launch-type FARGATE \
  --network-configuration "awsvpcConfiguration={subnets=[subnet-xxx],securityGroups=[sg-xxx],assignPublicIp=ENABLED}" \
  --load-balancers "targetGroupArn=arn:aws:elasticloadbalancing:...,containerName=web,containerPort=3000"

# Create signaling service
aws ecs create-service \
  --cluster swiftbridge-production \
  --service-name swiftbridge-signaling \
  --task-definition swiftbridge-signaling:1 \
  --desired-count 2 \
  --launch-type FARGATE \
  --network-configuration "awsvpcConfiguration={subnets=[subnet-xxx],securityGroups=[sg-xxx],assignPublicIp=ENABLED}" \
  --load-balancers "targetGroupArn=arn:aws:elasticloadbalancing:...,containerName=signaling,containerPort=8080"
```

### Option 2: Deploy to Vercel (Frontend Only)

#### 1. Install Vercel CLI

```bash
npm install -g vercel
```

#### 2. Configure Vercel Project

```bash
cd apps/web

# Login to Vercel
vercel login

# Link project
vercel link

# Set environment variables
vercel env add DATABASE_URL production
vercel env add REDIS_URL production
vercel env add JWT_SECRET production
# ... add all required environment variables
```

#### 3. Deploy to Production

```bash
# Deploy to production
vercel --prod

# Or use GitHub integration for automatic deployments
```

### Option 3: Deploy to DigitalOcean App Platform

#### 1. Create App Spec

```yaml
# app.yaml
name: swiftbridge
services:
  - name: web
    github:
      repo: yourusername/swiftbridge
      branch: main
      deploy_on_push: true
    dockerfile_path: apps/web/Dockerfile
    http_port: 3000
    instance_count: 2
    instance_size_slug: professional-xs
    envs:
      - key: DATABASE_URL
        scope: RUN_AND_BUILD_TIME
        value: ${db.DATABASE_URL}
      - key: REDIS_URL
        scope: RUN_AND_BUILD_TIME
        value: ${redis.REDIS_URL}
    
  - name: signaling
    github:
      repo: yourusername/swiftbridge
      branch: main
      deploy_on_push: true
    dockerfile_path: services/signaling/Dockerfile
    http_port: 8080
    instance_count: 2
    instance_size_slug: professional-xs

databases:
  - name: db
    engine: PG
    version: "15"
    size: db-s-2vcpu-4gb
    
  - name: redis
    engine: REDIS
    version: "7"
    size: db-s-1vcpu-1gb
```

#### 2. Deploy App

```bash
# Install doctl
brew install doctl  # macOS
# or download from https://github.com/digitalocean/doctl

# Authenticate
doctl auth init

# Create app
doctl apps create --spec app.yaml

# Get app ID
APP_ID=$(doctl apps list --format ID --no-header)

# Deploy
doctl apps create-deployment $APP_ID
```

## TURN Server Setup

### 1. Launch EC2 Instances

```bash
# Already created by Terraform
# Get instance IPs
terraform output coturn_public_ips
```

### 2. Configure coturn

SSH into each instance and verify coturn is running:

```bash
# SSH to instance
ssh ubuntu@<instance-ip>

# Check coturn status
sudo systemctl status coturn

# View logs
sudo journalctl -u coturn -f

# Test TURN server
turnutils_uclient -v -u swiftbridge -w swiftbridge_turn_secret_2024 <instance-ip>
```

### 3. Setup Load Balancing (Optional)

For high availability, setup DNS round-robin or use a load balancer:

```bash
# Add multiple A records in Cloudflare
turn1.swiftbridge.example -> IP1
turn2.swiftbridge.example -> IP2
```

## Monitoring Setup

### 1. Configure Sentry

```bash
# Install Sentry CLI
npm install -g @sentry/cli

# Login to Sentry
sentry-cli login

# Create new project
sentry-cli projects create swiftbridge

# Get DSN and add to environment variables
```

### 2. Setup CloudWatch Alarms

```bash
# Create alarm for high error rate
aws cloudwatch put-metric-alarm \
  --alarm-name swiftbridge-high-error-rate \
  --alarm-description "Alert when error rate is high" \
  --metric-name Errors \
  --namespace AWS/ECS \
  --statistic Sum \
  --period 300 \
  --threshold 10 \
  --comparison-operator GreaterThanThreshold \
  --evaluation-periods 2
```

### 3. Configure Prometheus + Grafana

```bash
# Deploy Prometheus
kubectl apply -f monitoring/prometheus-deployment.yaml

# Deploy Grafana
kubectl apply -f monitoring/grafana-deployment.yaml

# Import dashboards
# Access Grafana at http://grafana.swiftbridge.example
# Import dashboard JSON from monitoring/grafana/dashboards/
```

## Post-Deployment

### 1. Verify Deployment

```bash
# Check web application
curl https://swiftbridge.example/api/health

# Check signaling server
wscat -c wss://swiftbridge.example/ws

# Check TURN server
turnutils_uclient -v -u swiftbridge -w password turn.swiftbridge.example
```

### 2. Run Smoke Tests

```bash
# Run automated smoke tests
npm run test:smoke

# Or manually test:
# 1. Create account
# 2. Upload file
# 3. Share link
# 4. Download file
# 5. Verify encryption
```

### 3. Configure DNS

```bash
# Add DNS records in Cloudflare
A     @                  -> ALB IP
A     www                -> ALB IP
CNAME turn               -> turn1.swiftbridge.example
CNAME api                -> ALB DNS
CNAME ws                 -> ALB DNS

# Enable Cloudflare proxy (orange cloud)
```

### 4. Setup SSL Certificates

```bash
# Certificates are automatically provisioned by AWS ACM
# Verify certificate status
aws acm describe-certificate --certificate-arn <cert-arn>

# For Let's Encrypt (if not using ACM)
certbot certonly --dns-cloudflare \
  --dns-cloudflare-credentials ~/.secrets/cloudflare.ini \
  -d swiftbridge.example \
  -d *.swiftbridge.example
```

### 5. Configure Backups

```bash
# Enable automated RDS backups (already configured in Terraform)
# Verify backup configuration
aws rds describe-db-instances \
  --db-instance-identifier swiftbridge-production \
  --query 'DBInstances[0].BackupRetentionPeriod'

# Setup S3 bucket lifecycle for old uploads
aws s3api put-bucket-lifecycle-configuration \
  --bucket swiftbridge-production-uploads \
  --lifecycle-configuration file://s3-lifecycle.json
```

### 6. Setup Monitoring Alerts

Configure alerts for:
- High error rate
- Slow response times
- Database connection issues
- High memory usage
- TURN server failures
- SSL certificate expiration

### 7. Create Admin User

```bash
# Use the admin creation script
npm run create-admin -- --email admin@swiftbridge.example --password <secure-password>
```

## Troubleshooting

### Common Issues

#### 1. Database Connection Errors

```bash
# Check security group rules
aws ec2 describe-security-groups --group-ids sg-xxx

# Test connection from ECS task
aws ecs execute-command \
  --cluster swiftbridge-production \
  --task <task-id> \
  --container web \
  --interactive \
  --command "psql -h $DATABASE_URL"
```

#### 2. WebSocket Connection Failures

```bash
# Check ALB target health
aws elbv2 describe-target-health \
  --target-group-arn <target-group-arn>

# Check signaling server logs
aws logs tail /ecs/swiftbridge-production-signaling --follow
```

#### 3. TURN Server Not Working

```bash
# Check coturn logs
ssh ubuntu@<turn-server-ip>
sudo journalctl -u coturn -n 100

# Test TURN connectivity
turnutils_uclient -v -u swiftbridge -w password <turn-server-ip>

# Check firewall rules
sudo ufw status
```

#### 4. High Memory Usage

```bash
# Check ECS task metrics
aws cloudwatch get-metric-statistics \
  --namespace AWS/ECS \
  --metric-name MemoryUtilization \
  --dimensions Name=ServiceName,Value=swiftbridge-web \
  --start-time 2024-01-01T00:00:00Z \
  --end-time 2024-01-02T00:00:00Z \
  --period 3600 \
  --statistics Average

# Scale up if needed
aws ecs update-service \
  --cluster swiftbridge-production \
  --service swiftbridge-web \
  --desired-count 4
```

### Rollback Procedure

```bash
# Rollback to previous ECS task definition
aws ecs update-service \
  --cluster swiftbridge-production \
  --service swiftbridge-web \
  --task-definition swiftbridge-web:previous-version

# Or use Terraform
terraform apply -var="image_tag=previous-version"

# For Vercel
vercel rollback
```

### Getting Help

- Check logs: `aws logs tail /ecs/swiftbridge-production-web --follow`
- Review metrics: Access CloudWatch dashboard
- Check Sentry: Review error reports
- Contact support: support@swiftbridge.example

## Security Checklist

- [ ] All secrets stored in AWS Secrets Manager
- [ ] Database encrypted at rest
- [ ] SSL/TLS enabled for all connections
- [ ] Security groups properly configured
- [ ] IAM roles follow least privilege
- [ ] Backup and disaster recovery tested
- [ ] Monitoring and alerting configured
- [ ] Rate limiting enabled
- [ ] DDoS protection enabled (Cloudflare)
- [ ] Regular security audits scheduled

## Performance Optimization

### 1. Enable Caching

```bash
# Configure CloudFront distribution
aws cloudfront create-distribution --distribution-config file://cloudfront-config.json

# Configure Redis caching
# Update application to use Redis for session storage and caching
```

### 2. Optimize Database

```bash
# Create indexes
psql -h $RDS_ENDPOINT -U swiftbridge -d swiftbridge <<EOF
CREATE INDEX CONCURRENTLY idx_transfers_user_created 
  ON transfers(user_id, created_at DESC);
CREATE INDEX CONCURRENTLY idx_files_transfer_status 
  ON files(transfer_id, status);
EOF

# Analyze query performance
EXPLAIN ANALYZE SELECT * FROM transfers WHERE user_id = 'xxx';
```

### 3. Enable Auto-Scaling

```bash
# Configure ECS auto-scaling
aws application-autoscaling register-scalable-target \
  --service-namespace ecs \
  --resource-id service/swiftbridge-production/swiftbridge-web \
  --scalable-dimension ecs:service:DesiredCount \
  --min-capacity 2 \
  --max-capacity 10

aws application-autoscaling put-scaling-policy \
  --service-namespace ecs \
  --resource-id service/swiftbridge-production/swiftbridge-web \
  --scalable-dimension ecs:service:DesiredCount \
  --policy-name cpu-scaling \
  --policy-type TargetTrackingScaling \
  --target-tracking-scaling-policy-configuration file://scaling-policy.json
```

## Maintenance

### Regular Tasks

- **Daily**: Monitor error rates and performance metrics
- **Weekly**: Review logs and security alerts
- **Monthly**: Update dependencies and security patches
- **Quarterly**: Review and optimize costs
- **Annually**: Conduct security audit and disaster recovery drill

### Update Procedure

```bash
# 1. Test updates in staging
npm run deploy:staging

# 2. Run smoke tests
npm run test:smoke

# 3. Deploy to production
npm run deploy:production

# 4. Monitor for issues
# 5. Rollback if necessary
```

---

For more information, see the [main README](README.md) or contact the DevOps team.